package com.example.soteriasecurityapp;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    public FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button activity = findViewById(R.id.Activity);
        Button charts = findViewById(R.id.Charts);
        Button settings = findViewById(R.id.Settings);
        Button account = findViewById(R.id.Account);
        Button logout = findViewById(R.id.Logout);

        mAuth = FirebaseAuth.getInstance();


        logout.setOnClickListener(view -> {
            mAuth.signOut();
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        });


        activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity_1();
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSettings();
            }
        });

        charts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCharts();
            }
        });

        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAccount();
            }
        });

    }

    public void openActivity_1() {

        Intent intent = new Intent(this, Activity.class);
        startActivity(intent);
    }

    public void openSettings() {

        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    public void openCharts() {

        Intent intent = new Intent(this, Charts.class);
        startActivity(intent);
    }

    public void openAccount() {

        Intent intent = new Intent(this, Account.class);
        startActivity(intent);
    }

}




