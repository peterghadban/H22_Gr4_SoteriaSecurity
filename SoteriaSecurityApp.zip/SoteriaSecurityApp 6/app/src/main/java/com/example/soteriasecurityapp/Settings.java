package com.example.soteriasecurityapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Button account = findViewById(R.id.Account);
        Button notifications = findViewById(R.id.Notifications);
        Button alarm = findViewById(R.id.Alarm);
        Button help = findViewById(R.id.Help);



        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAccount();
            }
        });


        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNotifications();
            }
        });

        alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAlarm();
            }
        });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHelp();
            }
        });
    }

    public void openAccount() {

        Intent intent = new Intent(this, Account.class);
        startActivity(intent);

    }

    public void openNotifications() {

        Intent intent = new Intent(this, Notifications.class);
        startActivity(intent);
    }

    public void openAlarm() {

        Intent intent = new Intent(this, Alarm.class);
        startActivity(intent);
    }

    public void openHelp() {

        Intent intent = new Intent(this, Help.class);
        startActivity(intent);
    }
}