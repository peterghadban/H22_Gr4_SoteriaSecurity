package com.example.soteriasecurityapp;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.database.DatabaseReference;

public class User implements Parcelable {

    public String email, password, id;
    public DatabaseReference databaseReference;

    public User() {

    }

    public User(String username,String password, String id) {




        this.email = username;
        this.password = password;
        this.id = id;

    }

    protected User(Parcel in) {
        email = in.readString();
        password = in.readString();
        id = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(email);
        parcel.writeString(password);
        parcel.writeString(id);
    }
}
