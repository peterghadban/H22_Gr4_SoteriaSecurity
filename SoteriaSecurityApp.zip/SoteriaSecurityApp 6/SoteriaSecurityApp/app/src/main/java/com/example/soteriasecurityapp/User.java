package com.example.soteriasecurityapp;

public class User {

    protected String username, password;

    public User(){

    }

    public User(String username, String password){
        this.username = username;
        this.password = password;
    }

}
